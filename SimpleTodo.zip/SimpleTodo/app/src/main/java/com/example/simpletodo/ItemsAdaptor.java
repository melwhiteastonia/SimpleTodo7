package com.example.simpletodo;

import android.view.LayoutInflater;
import android.view.View;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import static android.R.layout.simple_list_item_1;


public class ItemsAdaptor extends RecyclerView.Adapter<ItemsAdaptor.ViewHolder>  {

    List<String> items;

    public ItemsAdaptor(List<String> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater.from(viewGroup.getContext()).inflate(simple_list_item_1, viewGroup, false);
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        String item = items.get(i);
        viewHolder.bind(item);

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // Container to provide easy access to views that represent each row of the List
    class ViewHolder extends RecyclerView.ViewHolder  {

        TextView tvItem;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItem = itemView.findViewById(android.R.id.text1);

        }

        //Update the view inside of the view holder with this data

        public void bind(String item) {
        }
    }
}
